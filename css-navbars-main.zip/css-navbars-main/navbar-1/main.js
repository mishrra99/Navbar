const toggleMenuOpen = () => document.body.classList.toggle("open");
